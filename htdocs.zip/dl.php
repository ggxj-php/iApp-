<meta charset="UTF-8">
<?php
session_start();
error_reporting(E_ALL^E_NOTICE^E_WARNING);
$user=$_POST["user"];
$pass=$_POST["password"];
if($user==""){
echo "<script>alert('账号不能为空');history.go(-1);</script>";
}
else if($pass==""){
echo "<script>alert('密码不能为空');history.go(-1);</script>";
}
else{
include_once("./configure/link1.php");
$pass=md5($pass);
$query=mysqli_query($link,"select * from login");
while($array=mysqli_fetch_array($query)){
if($array["user"]==$user){
$password=$array["password"];
}
}
if($password){
if($pass==$password){
$_SESSION["login"]=$user;
echo "<script>alert('登录成功');window.location.href='./index.php';</script>";
}
else{
echo "<script>alert('密码错误');history.go(-1);</script>";
}
}
else{
echo "<script>alert('账号不存在');history.go(-1);</script>";
}
}
?>