<?php
session_start();
if(!$_SESSION["login"]){
echo "<script>alert('您还没有登录哦');window.location.href='./';</script>";
}
?>
<meta charset="UTF-8" name="viewport" content="target-densitydpi=device-dpi,width=device-width, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0, user-scalable=no">
<title>iApp云后台-统计系统</title>
<button style='width:100%;height:50px;background:blue;color:white;' onclick="window.location.href='./tjtj.php';">添加统计</button>
<center>
<?php
include_once("./configure/link1.php");
inspect($_SESSION["login"]);
if(mysqli_num_rows(mysqli_query($link,"show tables like '".$_SESSION["login"]."tj'"))==0){
echo "<script>alert('发现您没有统计系统的数据表，如果要创建，请点击确定');</script>";
$create=mysqli_query($link,"CREATE TABLE ".$_SESSION["login"]."tj (apk text,page text)");
if($create){
echo "<script>alert('创建成功');window.location.href='./tjxt.php';</script>";
}
else{
echo "<script>alert('创建失败，请重试');</script>";
}
}
else{
$query=mysqli_query($link,"select * from ".$_SESSION["login"]."tj");
if(mysqli_num_rows($query)==0){
echo "您的数据库中没有任何在统计的应用</center>";
}
else{
while($row=mysqli_fetch_array($query)){
echo $row["apk"]."&nbsp<a href='./tjcx.php?apk=".$row["apk"]."&user=".$_SESSION["login"]."'>查看</a><br><div style='width:100%;height:1px;background:black'></div>";
}
}
}
?>