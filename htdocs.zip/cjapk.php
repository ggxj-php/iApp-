<?php
session_start();
error_reporting(E_ALL^E_NOTICE^E_WARNING);
include_once("./configure/link1.php");
?>
<meta charset="UTF-8" name="viewport" content="target-densitydpi=device-dpi,width=device-width, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0, user-scalable=no">
<head>
<title>iApp云后台-卡密系统添加应用</title>
</head>
<body>
<form action="" method="post">
<?php
edit("text","100%","50px","请输入应用名称","","apk");
$query=mysqli_query($link,"select * from ".$_SESSION["login"]."km");
edit("hidden","0","0","",mysqli_num_rows($query)+1,"id");
?>
<button style="height:50px;width:100%;background:blue;color:white;">创建</button>
</form>
</body>
<?php
if($_SESSION["login"]){
if($_POST["id"]){
if($_POST["apk"]==""){
utw("请您输入应用名称");
}
else if(strpos($_POST["apk"],">")){
utw("参数危险");
}
else if(strpos($_POST["apk"],"<")){
utw("参数危险");
}
else{
$get=mysqli_query($link,"insert into ".$_SESSION["login"]."km (apk,id) values('".$_POST["apk"]."','".$_POST["id"]."')");
$create=mysqli_query($link,"CREATE TABLE ".$_SESSION["login"]."km".$_POST["id"]." (km text,time text)");
if($get){
warn("创建成功");
}
else{
utw("创建失败");
}
}
}
}
else{
utw("请您先登录");
echo "<script>window.location.href='./';</script>";
}
?>