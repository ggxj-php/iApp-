<?php
session_start();
include_once("./configure/link1.php");
error_reporting(E_ALL^E_NOTICE^E_WARNING);
$user=$_GET["user"];
$pass=$_GET["password"];
$youruser=$_GET["youruser"];
if(strpos($user,"<")==true||strpos($password,"<")==true||strpos($password,">")==true||strpos($user,">")==true){
echo "<meta charset='UTF-8'><script>alert('账号或密码中含有危险字符');history.go(-1);</script>";
}
if($user==""||$pass==""){
echo "<meta charset='UTF-8'><script>alert('密码或密码不能为空');history.go(-1);</script>";
}
else if(preg_match('/[\x{4e00}-\x{9fa5}]/u',$user)){
echo "<meta charset='UTF-8'><script>alert('账号里不能含有中文');history.go(-1);</script>";
}
else{
if($link){
$date="select * from ".$youruser."user";
$zx=mysqli_query($link,$date);
while($row=mysqli_fetch_array($zx)){
if($user==$row["user"]){
$admin="yes";
}
}
if($admin){
echo "<meta charset='UTF-8'><script>alert('账号已经存在');history.go(-1);</script>";
}
else{
$insertdate="insert into ".$_GET["youruser"]."user (user,password,goldcoin,fhint,fh,zt) values('".$user."','".$pass."','1','','','正常')";
$insert=mysqli_query($link,$insertdate);
if($insert){
echo "user:".$user."/password:".$pass;
}
else{
$echo="<meta charset='UTF-8'><script>alert('数据库查询语句中出现错误 erro:数据插入失败');history.go(-1);</script>";
echo $echo;
}
}
}
else{
echo "<meta charset='UTF-8'><script>alert('SQL语句中出现错误 erro:数据库连接失败');history.go(-1);</script>";
}
}
?>