<html>
<meta charset="UTF-8" name="viewport" content="target-densitydpi=device-dpi,width=device-width, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0, user-scalable=no">
<head>
<title>iApp云后台-卡密系统2.0</title>
</head>
<body>
<center>
<form method='post' action=''>
<input type="text" name="apk" style="width:100%;height:50px;color:green;" placeholder="请输入需要创建的应用">
<button style="background:blue;color:white;height:50px;width:100%;">CREAT</button>
</form>
<?php
session_start();
include_once("../configure/link1.php");
if(!$_SESSION["login"]){
utw("您还没有登录哦");
directionalgo("../");
}
else{
$query=mysqli_query($link,"show tables like '".$_SESSION["login"]."cardpass'");
if(mysqli_num_rows($query)==0){
utw("检测到您是第一次进入本页面我们目前正在自动为您创建数据表");
$creatdatatable=mysqli_query($link,"CREATE TABLE ".$_SESSION["login"]."cardpass (apk text,id text)");
if($creatdatatable){
utw("normal");
directionalgo("./");
}
else{
utw("fail");
directionalgo("./");
}
}
else{
//检查数据表完毕
line();
$listarray=mysqli_query($link,"select * from ".$_SESSION["login"]."cardpass");
while($list=mysqli_fetch_array($listarray)){
echo "<a href='./mainpage.php?id=".$list["id"]."'>".$list["apk"]."</a>";
line();
}
if(mysqli_num_rows($listarray)==0){
echo "<h1>您还没有创建应用哦</h1>";
}
}
}
?>
</center>
</body>
</html>
<?php
if($_POST["apk"]){
$apk=$_POST["apk"];
if(strpos($apk,"<")){
utw("禁止输入危险字符");
}
else if(strpos($apk,">")){
utw("禁止输入危险字符");
}
else{
//检测通过
$getid=mysqli_query($link,"select * from ".$_SESSION["login"]."cardpass");
$id=mysqli_num_rows($getid)+1;
$creat=mysqli_query($link,"insert into ".$_SESSION["login"]."cardpass (apk,id) values('".$apk."','".$id."')");
$creatdata=mysqli_query($link,"CREATE TABLE ".$_SESSION["login"]."cardpass".$id." (card text,buytime text,cardtime text)");
if($creat){
utw("Success");
}
else{
utw("fail");
}
directionalgo("./");
}
}
?>