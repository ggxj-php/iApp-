<html>
<meta charset="UTF-8" name="viewport" content="target-densitydpi=device-dpi,width=device-width, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0, user-scalable=no">
<head>
<?php
session_start();
include_once("../configure/link1.php");
if(!$_SESSION["login"]){
utw("您还没有登录哦");
directionalgo("../");
}
else{
$titleget=mysqli_query($link,"select * from ".$_SESSION["login"]."cardpass where id=".$_GET["id"]);
while($titlearray=mysqli_fetch_array($titleget)){
$title=$titlearray["apk"];
}
echo "<title>iApp云后台-卡密系统:".$title."</title>";
}
?>
</head>
<body>
<center>
<?php
if(!$_GET["choose"]){
$geturl=$_SERVER["REQUEST_URI"];
echo "<a style='background:blue;color:white;width:100%&height:50px;' href='".$geturl."&choose=creatcard'>创建卡密</a><br>";
echo "<a style='background:blue;color:white;width:100%&height:50px;' href='".$geturl."&choose=diecard'>已使用卡密</a><br>";
echo "请选择对<font style='color:blue'>".$title."</font>的操作";
echo "<br>TIP:该软件专用卡密使用接口-http://".$_SERVER["SERVER_NAME"]."/cardpass/cardpassdie.php?cardpass=卡密&user=".$_SESSION["login"]."&id=".$_GET["id"];
}
else if($_GET["choose"]=="creatcard"){
//创建卡密
echo "<form action='' method='post'><input placeholder='请输入卡密时间   单位:小时' style='height:50px;width:100%;' name='time' type='txt'><button style='width:100%;height:50px;background:blue;color:white;'>创建</button></form>";
line();
$listarray=mysqli_query($link,"select * from ".$_SESSION["login"]."cardpass".$_GET["id"]);
while($list=mysqli_fetch_array($listarray)){
if($list["cardtime"]>0){
echo "卡密:".$list["card"]."<br>创建时间:".$list["buytime"]."<br>卡密时长:".$list["cardtime"]."小时";
line();
}
}
}
else if($_GET["choose"]=="diecard"){
//使用过的卡密
$num=0;
$listarra=mysqli_query($link,"select * from ".$_SESSION["login"]."cardpass".$_GET["id"]);
while($list=mysqli_fetch_array($listarra)){
if($list["cardtime"]==0){
echo "卡密:".$list["card"]."<br>卡密使用后到期时间:".$list["buytime"];
line();
$num=$num+1;
}
}
if($num==0){
echo "<h2>您还没有使用过卡密哦</h2>";
}

}

if($_POST["time"]){
if($_POST["time"]>0){
$word="qwertyuiopasdfghjklzxcvbnm";
$randa=rand(1,26);
$a=$randa-1;
$lettera=mb_substr($word,$a,1,"UTF-8");
$randb=rand(1,26);
$b=$randb-1;
$letterb=mb_substr($word,$b,1,"UTF-8");
$randc=rand(1,26);
$c=$randc-1;
$letterc=mb_substr($word,$c,1,"UTF-8");
$randd=rand(1,26);
$d=$randd-1;
$letterd=mb_substr($word,$d,1,"UTF-8");
$rande=rand(1,26);
$e=$rande-1;
$lettere=mb_substr($word,$e,1,"UTF-8");
$randf=rand(1,26);
$f=$randf-1;
$letterf=mb_substr($word,$f,1,"UTF-8");
$cardpass=$lettera.rand(20,45).$letterb.rand(1,10).$letterc.$letterd.rand(199,999).$lettere.$letterf;
$query=mysqli_query($link,"insert into ".$_SESSION["login"]."cardpass".$_GET["id"]." (card,buytime,cardtime) values('".$cardpass."','".date("Y-m-d H:i:s")."','".$_POST["time"]."')");
if($query){
echo "创建成功&nbsp;卡密:".$cardpass."&nbsp;时长:".$_POST["time"]."小时";
}
}
else{
echo "卡密时长不符合要求";
}
}
?>
</center>
</body>
</html>