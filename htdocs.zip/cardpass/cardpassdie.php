<?php
include_once("../configure/link1.php");
$cardpass=$_GET["cardpass"];
$user=$_GET["user"];
$id=$_GET["id"];
if($cardpass==""&&$user==""&&$id==""){
echo "缺少必要参数";
}
else if(strpos($cardpass,"<")||strpos($cardpass,">")){
echo "参数危险";
}
$query=mysqli_query($link,"select * from login");
while($row=mysqli_fetch_array($query)){
if($row["user"]==$user){
$if=1;
}
}
if($if){
$idlist=mysqli_query($link,"select * from ".$user."cardpass");
while($arr=mysqli_fetch_array($idlist)){
if($arr["id"]==$id){
$ifid=1;
}
}
if($ifid){
$cardpassif=mysqli_query($link,"select * from ".$user."cardpass".$id);
while($row=mysqli_fetch_array($cardpassif)){
if($row["card"]==$cardpass){
$cardif=1;
$cardpassword=$row["card"];
$cardtime=$row["cardtime"];
}
}
if($cardif&&$cardtime>0){
//判断完成
$t=date("Y-m-d H:i:s",strtotime("+".$cardtime."hours"));
$query=mysqli_query($link,"update ".$user."cardpass".$id." set card='".$cardpassword."',buytime='".$t."',cardtime='0' where card='".$cardpass."'");
if($query){
echo "卡密使用成功&nbsp;到期时间:".$t;
}
else{
echo "使用失败";
}
}
else{
echo "卡密不存在或已经被使用";
}
}
else{
echo "参数错误";
}
}
else{
echo "参数错误";
}
?>