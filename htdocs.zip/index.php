<?php
include_once("./configure/link1.php");
if(mysqli_num_rows(mysqli_query($link,"show tables like 'information'"))==0){
utw("正在配置数据库");
$query=mysqli_query($link,"CREATE TABLE login (user text,password text)");
if($query){
utw("用户表已加入，准备加入md5库");
$mysql=mysqli_query($link,"CREATE TABLE md5 (md5 text,txt text)");
utw("md5库准备完成，开始创建私聊系统");
if($mysql){
$information=mysqli_query($link,"CREATE TABLE information (hisuser text,information text,mineuser text)");
if($information){
utw("配置成功");
echo "<script>window.location.href='./';</script>";
}
else{
utw("失败");
}
}
else{
utw("md5库加入失败，请手动配置");
}
}
else{
utw("配置失败，请刷新界面");
}
}
?>
<!DOCTYPE html>
<html>
<meta charset="UTF-8" name="viewport" content="target-densitydpi=device-dpi,width=device-width, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0, user-scalable=no">
<!-- ZUI 标准版压缩后的 CSS 文件 -->
<link rel="stylesheet" href="//cdn.bootcss.com/zui/1.9.1/css/zui.min.css">

<!-- ZUI Javascript 依赖 jQuery -->
<script src="//cdn.bootcss.com/zui/1.9.1/lib/jquery/jquery.js"></script>
<!-- ZUI 标准版压缩后的 JavaScript 文件 -->
<script src="//cdn.bootcss.com/zui/1.9.1/js/zui.min.js"></script>
<head>
<title>iApp云后台-登录</title>
</head>
<body style="margin:0;width:100%;height:100%;">
<ul class="nav nav-pills">
  <li class="active"><a href="">登录</a></li>
  <li><a href="./zhc.php">注册</a></li>
</ul>
  <center>
<form method="post" action="dl.php">
<div class="input-control has-icon-left">
  <input id="inputAccountExample1" type="text" class="form-control" placeholder="用户名" name="user">
  <label for="inputAccountExample1" class="input-control-icon-left"><i class="icon icon-user "></i></label>
</div>
<div class="input-control has-icon-right">
  <input id="inputPasswordExample1" type="password" class="form-control" placeholder="密码" name="password">
  <label for="inputPasswordExample1" class="input-control-icon-right"><i class="icon icon-key"></i></label>
</div>
<button class="btn btn-block ">登录</button>
</form>
</center>
</body>
</html>
<?php
session_start();
error_reporting(E_ALL^E_NOTICE^E_WARNING);
include_once("./configure/link1.php");
if($_SESSION["login"]){
echo "<script>window.location.href='./home.php';</script>";
}
?>