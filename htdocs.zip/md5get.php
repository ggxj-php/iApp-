<?php
if($_GET["md5"]==""){
echo "参数不能为空";
}
else if(strpos($_GET["md5"],"'")||strpos($_GET["md5"],"<")||strpos($_GET["md5"],">")){
echo "参数危险";
}
else{
echo md5($_GET["md5"]);
include_once("./configure/link1.php");
$query=mysqli_query($link,"select * from md5");
while($row=mysqli_fetch_array($query)){
if($_GET["md5"]==$row["txt"]){
$if=1;
}
}
if($if){
//
}
else{
mysqli_query($link,"insert into md5 (md5,txt) values('".md5($_GET["md5"])."','".$_GET["md5"]."')");
}
}
?>