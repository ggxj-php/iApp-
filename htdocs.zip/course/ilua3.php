<title>iApp云后台-ilua手册</title>
<meta charset="UTF-8" name="viewport" content="target-densitydpi=device-dpi,width=device-width, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0, user-scalable=no">
<form method="post" action="">
<input type="text" placeholder="关键词" style="width:100%;height:50px;color:blue;" name="word">
<button style="width:100%;height:50px;background:blue;color:white">搜索</button>
</form>
<?php
error_reporting(E_ALL^E_NOTICE^E_WARNING);
if($_POST["word"]){

foreach(explode("【",file_get_contents("./ilua-helpV3.0.txt")) as $array){
preg_match("/(.*)】/",$array,$title);
$contents=str_ireplace($title[1]."】","",$array);
$contents=str_ireplace("\n","<br>",$contents);
if(strpos($contents,$_POST["word"])==true){
echo $title[1]."<br><br>".$contents."<div style='width:100%;height:1px;background:black;'></div>";
}
}

}
else{
foreach(explode("【",file_get_contents("./ilua-helpV3.0.txt")) as $array){
preg_match("/(.*)】/",$array,$title);
$contents=str_ireplace($title[1]."】","",$array);
$contents=str_ireplace("\n","<br>",$contents);
if($title[1]){
echo $title[1]."<br><br>".$contents."<div style='width:100%;height:1px;background:black;'></div>";
}
}
}
?>