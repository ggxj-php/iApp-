<?php
include_once("./configure/link1.php");
$query=mysqli_query($link,"select * from md5");
while($row=mysqli_fetch_array($query)){
if($row["md5"]==$_GET["md5"]){
$if=1;
$txt=$row["txt"];
}
}
if($if){
echo "解密内容:".$txt;
}
else{
echo "本站无法解密此MD5";
}
?>