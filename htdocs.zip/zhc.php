<!DOCTYPE html>
<html>
<!-- ZUI 标准版压缩后的 CSS 文件 -->
<link rel="stylesheet" href="//cdn.bootcss.com/zui/1.9.1/css/zui.min.css">

<!-- ZUI Javascript 依赖 jQuery -->
<script src="//cdn.bootcss.com/zui/1.9.1/lib/jquery/jquery.js"></script>
<!-- ZUI 标准版压缩后的 JavaScript 文件 -->
<script src="//cdn.bootcss.com/zui/1.9.1/js/zui.min.js"></script>
<meta charset="UTF-8" name="viewport" content="target-densitydpi=device-dpi,width=device-width, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0, user-scalable=no">
<head>
<title>iApp云后台-注册</title>
</head>
<body style="margin:0;width:100%;height:100%;">
<ul class="nav nav-pills">
  <li><a href="./index.php">登录</a></li>
  <li class="active"><a href="">注册</a></li>
</ul>
  <center>
<form method="post" action="zc.php">
<div class="input-control has-icon-left">
  <input id="inputAccountExample1" type="text" class="form-control" placeholder="用户名" name="user">
  <label for="inputAccountExample1" class="input-control-icon-left"><i class="icon icon-user "></i></label>
</div>
<div class="input-control has-icon-right">
  <input id="inputPasswordExample1" type="password" class="form-control" placeholder="密码" name="password">
  <label for="inputPasswordExample1" class="input-control-icon-right"><i class="icon icon-key"></i></label>
</div>
<div class="input-control has-icon-right">
  <input id="inputPasswordExample1" type="text" class="form-control" placeholder="验证码" name="yzm">
  <label for="inputPasswordExample1" class="input-control-icon-right"><i class="icon icon-key"></i></label>
</div>
<img id="verImg" src="yzm.php"/>
        <a href="#" class="change" onclick="changeVer()">看不清?换一张</a>
<script type="text/javascript">
    function changeVer(){
        document.getElementById("verImg").src="./yzm.php";
    }
    </script>
<button class="btn btn-block ">注册</button>
</form>
</center>
</div>
</body>
</html>