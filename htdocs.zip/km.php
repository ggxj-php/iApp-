<?php
session_start();
include_once("./configure/link1.php");
?>
<meta charset="UTF-8" name="viewport" content="target-densitydpi=device-dpi,width=device-width, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0, user-scalable=no">
<head>
<title>iApp云后台-卡密系统</title>
</head>
<body>
<button style="height:50px;width:100%;background:blue;color:white;" onclick="window.location.href='./cjapk.php';">创建应用</button>
<?php
inspect($_SESSION["login"]);
if(mysqli_num_rows(mysqli_query($link,"show tables like '".$_SESSION["login"]."km'"))==0){
utw("您还没有创建卡密数据库，请问您要创建吗?");
$query=mysqli_query($link,"CREATE TABLE ".$_SESSION["login"]."km (apk text,id text)");
if($query){
utw("创建成功");
}
else{
utw("啊欧，创建失败了");
}
}
else{
if(mysqli_num_rows(mysqli_query($link,"select * from ".$_SESSION["login"]."km"))==0){
echo "<br><br><center>您的卡密数据库没有任何应用</center>";
}
else{
$apkarray=mysqli_query($link,"select * from ".$_SESSION["login"]."km");
while($array=mysqli_fetch_array($apkarray)){
line();
echo "<center><a href='./kmapk.php?id=".$array["id"]."'>".$array["apk"]."</a></center>";
line();
}
}
}
?>
</body>
<?php
if(!$_SESSION["login"]){
warn("请您先登录");
}
?>