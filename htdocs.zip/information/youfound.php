<?php
session_start();
include_once("../configure/link1.php");
if(!$_SESSION["login"]){
echo "<script>window.location.href='../';</script>";
}
?>
<meta charset="UTF-8" name="viewport" content="target-densitydpi=device-dpi,width=device-width, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0, user-scalable=no">
<head>
<title>iApp云后台-你私聊的人</title>
</head>
<?php
$query=mysqli_query($link,"select * from information where mineuser='".$_SESSION["login"]."'");
while($array=mysqli_fetch_array($query)){
echo "<center><a href='./chat.php?id=".$array["id"]."&hisuser=".$array["hisuser"]."&mineuser=".$array["mineuser"]."'>".$array["hisuser"]."</a></center>";
line();
}
if(mysqli_num_rows($query)==0){
echo "<center>您没有找任何人私聊</center>";
}
?>