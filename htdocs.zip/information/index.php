<?php
session_start();
include_once("../configure/link1.php");
if(!$_SESSION["login"]){
utw("您还没有登录");
echo "<script>window.location.href='../';</script>";
}
?>
<html>
<meta charset="UTF-8" name="viewport" content="target-densitydpi=device-dpi,width=device-width, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0, user-scalable=no">
<head>
<title>iApp云后台-与其他用户私聊</title>
</head>
<body>
<form action="" method="post">
<input name="hisuser" type="txt" placeholder="对方用户名" style="width:100%;height:50px;">
<button style="width:100%;height:50px;background:blue;color:white;">创建对话</button>
</form>
<script>
function foundyou(){
window.location.href="./foundyou.php";
}
function youfound(){
window.location.href="./youfound.php";
}
</script>
<button style="width:100%;height:50px;background:blue;color:white;" onclick="foundyou();">找你对话的人</button>
<button style="width:100%;height:50px;background:blue;color:white;" onclick="youfound();">你发起的对话列表</button>
<p>想和站长(网站开发者)聊天吗?我账号:ggxj</p>
</body>
</html>
<?php
if($_POST["hisuser"]){
$hisuser=$_POST["hisuser"];
$query=mysqli_query($link,"select * from login");
while($row=mysqli_fetch_array($query)){
if($row["user"]==$hisuser){
$if=1;
}
}
if($if){
if($hisuser==$_SESSION["login"]){
utw("不能与自己对话");
}
else{
$id=mysqli_num_rows(mysqli_query($link,"select * from information"))+1;
$mysql=mysqli_query($link,"insert into information (hisuser,information,mineuser,id) values('".$hisuser."','','".$_SESSION["login"]."','".$id."')");
if($mysql){
utw("创建成功");
}
else{
utw("创建失败");
}
}
}
else{
utw("输入的账号不存在");
}
}
?>