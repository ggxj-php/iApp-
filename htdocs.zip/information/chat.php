<?php
session_start();
include_once("../configure/link1.php");
if(!$_SESSION["login"]){
utw("您还没有登录哦");
echo "<script>window.location.href='../';</script>";
}
?>
<meta charset="UTF-8" name="viewport" content="target-densitydpi=device-dpi,width=device-width, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0, user-scalable=no">
<head>
<title>聊天</title>
</head>
<body>
<div style="background:black;height:9%;width:100%;position:fixed;top:0;left:0;"><center><p style="color:white;">聊天</p></div>
<div style="margin:70px;">
<?php
$query=mysqli_query($link,"select * from information where id='".$_GET["id"]."'");
while($row=mysqli_fetch_array($query)){
$content=$row["information"];
}
foreach(explode("【ゎ】",$content) as $array){
echo $array;
line();
}
?>
</div>
<div style="width:100%;height:9%;position:fixed;bottom:0;left:0;">
<center>
<form action="" method="get">
<?php
echo "<input type='hidden' name='hisuser' value='".$_GET["hisuser"]."'>";
echo "<input type='hidden' name='mineuser' value='".$_GET["mineuser"]."'>";
echo "<input type='hidden' name='id' value='".$_GET["id"]."'>";
?>
<input name="get" type="txt" placeholder="发送的内容" style="width:80%;height:50px;"><button style="background:blue;height:50px;width:18%;color:white;">提交</button>
</form>
</center>
</div>
</body>
<?php
error_reporting(E_ALL^E_NOTICE^E_WARNING);
if($_GET["get"]){
$get=$_GET["get"];
if(strpos($get,"<")||strpos($get,">")){
utw("禁止输入危险字符");
}
else{
if($content==""){
$con=$_SESSION["login"].":".$get;
}
else{
$con=$content."【ゎ】".$_SESSION["login"].":".$get;
}
$c="update information set hisuser='".$_GET["hisuser"]."',information='".$con."',mineuser='".$_GET["mineuser"]."',id='".$_GET["id"]."' where id='".$_GET["id"]."'";
$my=mysqli_query($link,$c);
if($my){
utw("发送成功");
echo "<script>history.go(-1);</script>";
}
else{
utw("发送失败");
}
}
}
?>