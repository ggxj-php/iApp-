<?php
session_start();
include_once("./configure/link1.php");
error_reporting(E_ALL^E_NOTICE^E_WARNING);
$user=$_POST["user"];
$pass=$_POST["password"];
if($user==""||$pass==""){
echo "<meta charset='UTF-8'><script>alert('密码或密码不能为空');history.go(-1);</script>";
}
else if(preg_match('/[\x{4e00}-\x{9fa5}]/u',$user)){
echo "<meta charset='UTF-8'><script>alert('账号里不能含有中文');history.go(-1);</script>";
}
else if($_POST["yzm"]==$_SESSION["yzm"]){
if($link){
$date="select * from login";
$zx=mysqli_query($link,$date);
while($row=mysqli_fetch_array($zx)){
if($user==$row["user"]){
$admin="yes";
}
}
if($admin=="yes"){
echo "<meta charset='UTF-8'><script>alert('账号已经存在');history.go(-1);</script>";
}
else{
$insertdate="insert into login (user,password) values('".$user."','".md5($pass)."')";
$insert=mysqli_query($link,$insertdate);
if($insert){
echo "<meta charset='UTF-8'><script>alert('注册成功');window.location.href='./index.php';</script>";
include_once("./configure/link1.php");
$contents="CREATE TABLE ".$user."text
(
id text,
title text,
contents text
)";
mysqli_query($link,$contents);
$contents="CREATE TABLE ".$user."user
(
user text,
password text,
goldcoin text,
fhint text,
fh text,
zt text
)";
mysqli_query($link,$contents);
}
else{
$echo="<meta charset='UTF-8'><script>alert('数据库查询语句中出现错误 erro:数据插入失败');history.go(-1);</script>";
echo $echo;
}
}
}
else{
echo "<meta charset='UTF-8'><script>alert('SQL语句中出现错误 erro:数据库连接失败');history.go(-1);</script>";
}
}
else{
echo "<script>alert('验证码错误');history.go(-1);</script>";
}
?>