<?php

$user=$_GET["user"];
$pass=$_GET["password"];
$youruser=$_GET["youruser"];
if($youruser==""){
echo "参数错误";
}
else if($user==""){
echo "<script>alert('账号不能为空');history.go(-1);</script>";
}
else if($pass==""){
echo "<script>alert('密码不能为空');history.go(-1);</script>";
}
else{
include_once("./configure/link1.php");
$query=mysqli_query($link,"select * from ".$youruser."user");
while($array=mysqli_fetch_array($query)){
if($array["user"]==$user){
$if="123";
$password=$array["password"];
$zt=$array["zt"];
$fhint=$array["fhint"];
$fh=$array["fh"];
$jb=$array["goldcoin"];
}
}
if($if){
if($pass==$password){
if($zt=="正常"){
echo "登录成功";
}
else{
$date=date("Ymd");
if($date>=$fhint){
$qy=mysqli_query($link,"update ".$_GET["youruser"]."user set user='".$user."',password='".$pass."',goldcoin='".$jb."',fhint='',fh='',zt='正常' where user='".$user."'");
if($qy){
echo "登录成功";
}
else{
echo "尊敬的用户，由于系统问题，禁封时间已过可并没有解封，请您尝试重新登录";
}
}
else{
echo "封号截止到:".$fh;
}
}
}
else{
echo "<script>alert('密码错误');history.go(-1);</script>";
}
}
else{
echo "<script>alert('账号不存在');history.go(-1);</script>";
}
}
?>