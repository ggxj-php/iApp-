<?php
session_start();
include_once("./configure/link1.php");
error_reporting(E_ALL^E_NOTICE^E_WARNING);
$id=$_GET["id"];
$while=mysqli_query($link,"select * from ".$_SESSION["login"]."text");
while($row=mysqli_fetch_array($while)){
if($row["id"]==$id){
$title=$row["title"];
$contents=$row["contents"];
}
$contents=str_ireplace("<br>","[br]",$contents);
$contents=str_ireplace("&nbsp;","&nbsp;",$contents);
}
if(!$title){
echo "<script>alert('ID错误');history.go(-1);</script>";
exit;
}
?>
<meta charset="UTF-8" name="viewport" content="target-densitydpi=device-dpi,width=device-width, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0, user-scalable=no">
<title>iApp后台-远程文本修改</title>
<body style="margin:0;">
<center>
<form action="textxgtj.php" method="get">
<?php
echo "<input type='text' placeholder='请输入需要修改的标题' style='width:100%;height:50px;' name='title' value='".$title."'>";
echo "<input type='text' placeholder='请输入需要修改的内容' style='width:100%;height:50px;' name='contents' value='".$contents."'>";
echo "<input type='text' placeholder='您在本站的密码' style='width:100%;height:50px;' name='password'>";
echo "<input type='hidden' name='id' value='".$id."'>";
echo "<input type='hidden' name='user' value='".$_SESSION["login"]."'>";
?>
<button style="width:100%;height:50px;background:blue;color:white;" name="button">上传</button>
</form>
</center>
<?php
echo "TIP:修改接口-http://".$_SERVER["SERVER_NAME"]."/textxgtj.php?title=修改的标题&contents=修改内容&id=".$id."&user=您在本站的账号&password=您在本站的密码<br>注意:本接口只能修改本文本，如要修改其他文本请到对应远程文本的修改页面复制接口";
?>
</body>