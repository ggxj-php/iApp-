<?php
session_start();
error_reporting(E_ALL^E_NOTICE^E_WARNING);
//配置信息
include_once("./configure/link1.php");
if(!$_SESSION["login"]){
echo "<script>alert('您还没有登录或登录已失效');window.location.href='./index.php';</script>";
exit;
}
?>
<title>iApp云后台</title>
<!-- ZUI 标准版压缩后的 CSS 文件 -->
<link rel="stylesheet" href="//cdn.bootcss.com/zui/1.9.1/css/zui.min.css">

<!-- ZUI Javascript 依赖 jQuery -->
<script src="//cdn.bootcss.com/zui/1.9.1/lib/jquery/jquery.js"></script>
<!-- ZUI 标准版压缩后的 JavaScript 文件 -->
<script src="//cdn.bootcss.com/zui/1.9.1/js/zui.min.js"></script>
<meta name="viewport" content="width=device-width, initial-scale=1">
<ul class="nav nav-pills">
<ul class="nav nav-primary">
<li><a>iApp云后台</a></li>
  <li class="active"><a href="/home.php">首页</a></li>
  <li><a href="information">私聊</a></li>
  <li>
    <a class="dropdown-toggle" data-toggle="dropdown" href="">后台功能 <span class="caret"></span></a>
    <ul class="dropdown-menu">
      <li><a href="text.php">空白文档</a></li>
      <li><a href="yh.php">用户系统</a></li>
      <li><a href="yclist.php">远程列表</a></li>
      <li><a href="tjxt.php">统计系统</a></li>
      <li><a href="md5.php">MD5加密</a></li>
      <li><a href="md5jm.php">MD5解密</a></li>
      <li><a href="ip.php">IP获取</a></li>
      <li><a href="km.php">卡密系统</a></li>
      <li><a href="cardpass">卡密系统2.0</a></li>
      <li><a href="course">iApp教程</a></li>
    </ul>
  </li>
</ul>
<article class="article">
  <!-- 文章头部 -->
  <header>
    <h1>公告</h1>
    <!-- 文章属性列表 -->
    <dl class="dl-inline">
      <dt></dt>
      <dd></dd>
      
    </dl>
    <div class="abstract">
      <p>亲爱的用户:<?php echo $_SESSION["login"]; ?>您好</p>
    </div>
  </header>
  <!-- 文章正文部分 -->
  <section class="content">
    欢迎使用iApp云后台，已经有如下用户加入了我们:<br>
    <?php
    $user=mysqli_query($link,"select * from login");
    while($list=mysqli_fetch_array($user)){
    echo $list["user"]."<br>";
    }
    ?>
  </section>
  <footer>
    <ul class="pager pager-justify">
      <li class="previous"><a href="#"><i class="icon-arrow-left"></i> 上一篇</a></li>
      <li><a href="#"><i class="icon-list-ul"></i> 目录</a></li>
      <li class="next disabled"><a href="#">没有下一篇 <i class="icon-arrow-right"></i></a></li>
    </ul>
  </footer>
</article>
<?php
inspect($_SESSION["login"]);
//开始
//统计
$date=date('Y-m-d H:i:s');
$content="[".$date."]IP:".$_SERVER['REMOTE_ADDR'];
$get=file_get_contents("./Journal/".date("Y-m-d").".txt");
if($get==""){
$nr=$content;
}
else{
$nr=$get."\n".$content;
}
file_put_contents("./Journal/".date("Y-m-d").".txt",$nr);
$get=file_get_contents("./Journal/pv.txt");
$contents=$get+1;
file_put_contents("./Journal/pv.txt",$contents);
$sr=str_replace(".","",file_get_contents("./Journal/".date("Y-m-d")."独立IP.txt"));
$sr1=str_replace(".","",$_SERVER["REMOTE_ADDR"]);
foreach(explode("\n",$sr) as $cq){
if($sr1==$cq){
$pd="yes";
}
}
if($pd!=="yes"){
if(file_get_contents("./Journal/".date("Y-m-d")."独立IP.txt")==""){
file_put_contents("./Journal/".date("Y-m-d")."独立IP.txt",$_SERVER["REMOTE_ADDR"]);
}
else{
file_put_contents("./Journal/".date("Y-m-d")."独立IP.txt",file_get_contents("./Journal/".date("Y-m-d")."独立IP.txt")."\n".$_SERVER["REMOTE_ADDR"]);
}
}
$number=0;
foreach(explode("\n",file_get_contents("./Journal/".date("Y-m-d")."独立IP.txt")) as $array){
$number=$number+1;
}
$number1=0;
foreach(explode("\n",file_get_contents("./Journal/".date("Y-m-d").".txt")) as $array1){
$number1=$number1+1;
}
$user=mysqli_num_rows(mysqli_query($link,"select * from login"));
$yesterday=0;
$datey="20".date("y");
$datem=date("m");
$date1=date("d")-1;
if($date1<10){
$date1="0".$date1;
}
else if($date1==0){
if(date("m")=="01"||date("m")=="03"||date("m")=="04"||date("m")=="06"||date("m")=="09"||date("m")=="11"){
$date1=31;
}
else if(date("m")=="02"){
$Calculation=$datey/4;
if(strpos($Calculation,".")){
$date1=28;
}
else{
$date1=29;
}
}
else{
$date1=30;
}
}
$name="./Journal/".$datey."-".$datem."-".$date1."独立IP.txt";
foreach(explode("\n",file_get_contents($name)) as $foreach){
$yesterday=$yesterday+1;
}
?>
<div class="modal fade" id="myModal">
  <div class="modal-dialog">
    <div class="modal-content">
      本统计系统由ggxj编写
    </div>
  </div>
</div>
<?php
echo "<p style='color:blue;' data-toggle='modal' data-target='#myModal'>网站总PV[".file_get_contents("./Journal/pv.txt")."]今日PV[".$number1."]今日IP[".$number."]昨日IP[".$yesterday."]当前共有用户[".$user."]</p></div></body>";
?>