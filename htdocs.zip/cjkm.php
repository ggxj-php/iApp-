<?php
session_start();
?>
<meta charset="UTF-8" name="viewport" content="target-densitydpi=device-dpi,width=device-width, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0, user-scalable=no">
<?php
include_once("./configure/link1.php");
error_reporting(E_ALL^E_NOTICE^E_WARNING);
$b=$_GET["id"];
$a=$_GET["type"];
if($_GET["type"]==""||$_GET["id"]==""){
warn("缺少参数");
}
else if(strpos($_GET["type"],"<")||strpos($_GET["type"],">")||strpos($_GET["id"],"<")||strpos($_GET["id"],">")){
warn("参数危险");
}
else{
$qid=mysqli_query($link,"select * from ".$_SESSION["login"]."km");
while($ai=mysqli_fetch_array($qid)){
if($ai["id"]==$b){
$iget="yes";
}
}
if($a=="day"||$a=="year"||$a=="month"){
$tget="yes";
}
if($iget&&$tget){
$km=date("YmdHis");
$time=date("YmdHis");

if($a=="day"){
if(date("d")<="27"){
$time=$time+1000000;
}
else if(date("m")=="1"||date("m")=="3"||date("m")=="5"||date("m")=="7"||date("m")=="8"||date("m")=="10"||date("m")=="12"){
if(date("d")=="31"){
$time=$time+100000000-30000000;
}
else{
$time=$time+1000000;
}
}
else if(date("m")=="2"){
$year=date("Y")/4;
if(strpos($year,".")&&$date("d")=="28"){
$time=$time+100000000-27000000;
}
else{
$time=$time+10000000000-2800000000;
}
}
else{
if(date("d")=="30"){
$time=$time+100000000-29000000;
}
else{
$time=$time+1000000;
}
}
}
else if($a=="month"){
if(date("m")<="11"){
$time=$time+100000000;
}
else if(date("m")=="12"){
$time=$time+10000000000-1200000000;
}
}
else if($a=="year"){
$time=$time+10000000000;
}
$kmcr=mysqli_query($link,"insert into ".$_SESSION["login"]."km".$_GET["id"]." (km,time) values('".$km."','".$time."')");
if($kmcr){
echo "您的卡密:".$km."<br>卡密到期时间(VIP等到期时间):".$time;
}
else{
warn("啊欧，创建失败了");
}
}
else{
warn("参数有误");
}
}
?>