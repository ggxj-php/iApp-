<?php
session_start();
if(!$_SESSION["login"]){
echo "<script>alert('您还没有登录哦');window.location.href='./';</script>";
exit;
}
?>
<meta charset="UTF-8" name="viewport" content="target-densitydpi=device-dpi,width=device-width, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0, user-scalable=no">
<head>
<title>iApp云后台-统计系统应用添加</title>
</head>
<body>
<form action="" method="post">
<input type="text" name="apk" placeholder="请输入应用名称" style="width:100%;height:50px;">
<input type="hidden" name="h" value="1">
<button style='width:100%;height:50px;background:blue;color:white;'>提交</button>
</form>
</body>
<?php
if($_POST["h"]){
if(strpos($_POST["apk"],"<")){
echo "<script>alert('请勿输入危险字符');</script>";
}
else if(strpos($_POST["apk"],">")){
echo "<script>alert('请勿输入危险字符');</script>";
}
else if($_POST["apk"]==""){
echo "<script>alert('请输入应用名称');</script>";
}
else{
include_once("./configure/link1.php");
$query=mysqli_query($link,"select * from ".$_SESSION["login"]."tj");
while($row=mysqli_fetch_array($query)){
if($row["apk"]==$_POST["apk"]){
$q=1;
}
}
if($q){
echo "<script>alert('该应用已存在');history.go(-1);</script>";
}
else{
$quer=mysqli_query($link,"insert into ".$_SESSION["login"]."tj (apk,page) value('".$_POST["apk"]."','./tjxt/".$_SESSION["login"]."→".$_POST["apk"]."')");
if($quer){
echo "<script>alert('成功');</script>";
file_put_contents("./tjxt/".$_SESSION["login"]."→".$_POST["apk"]."pv.txt","0");
}
else{
echo "<script>alert('失败');</script>";
}
}
}
}
?>