<?php
include_once("./configure/link1.php");
$query=mysqli_query($link,"select * from login");
while($row=mysqli_fetch_array($query)){
if($row["user"]==$_GET["user"]){
$if="yes";
}
}
if($if){
$que=mysqli_query($link,"select * from ".$_GET["user"]."km");
while($ro=mysqli_fetch_array($que)){
if($ro["id"]==$_GET["id"]){
$i="yes";
}
}
if($i){
$kmc=mysqli_query($link,"select * from ".$_GET["user"]."km".$_GET["id"]);
while($r=mysqli_fetch_array($kmc)){
if($r["km"]==$_GET["km"]){
$f="yes";
$time=$r["time"];
}
}
if($f){
$my=mysqli_query($link,"delete from ".$_GET["user"]."km".$_GET["id"]." where km='".$_GET["km"]."'");
if($my){
echo "卡密使用成功<br>到期时间:".$time;
utw("提示:请务必保存改日期，以便判断VIP等是否到期");
}
else{
echo "卡密使用失败";
}
}
else{
echo "卡密不存在";
}
}
else{
echo "参数有误";
}
}
else{
echo "参数有误";
}
?>