<?php
session_start();
if(!$_SESSION["login"]){
echo "<script>alert('您还没有登录哦');window.location.href='./';</script>";
}
include_once("./configure/link1.php");
inspect($_SESSION["login"]);
?>
<meta charset="UTF-8" name="viewport" content="target-densitydpi=device-dpi,width=device-width, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0, user-scalable=no">
<title>iApp云后台-MD5加密</title>
<form method="get" action="md5get.php">
<input type="txt" placeholder="请输入需要加密的字符" style="width:100%;height:50px;" name="md5">
<button style='width:100%;height:50px;background:blue;color:white;'>加密</button>
</form>
<?php
echo "TIP:MD5加密接口-http://".$_SERVER["SERVER_NAME"]."/md5get.php?md5=需要加密的字符";
?>