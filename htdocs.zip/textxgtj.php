<?php
session_start();
error_reporting(E_ALL^E_NOTICE^E_WARNING);
$id=$_GET["id"];
include_once("./configure/link1.php");
$a=mysqli_query($link,"select * from login");
while($rw=mysqli_fetch_array($a)){
if($rw["user"]==$_GET["user"]){
$aq=1;
}
}
$b=mysqli_query($link,"select * from login");
while($rwo=mysqli_fetch_array($b)){
if($rwo["password"]==$_GET["password"]){
$aqo=1;
}
}
if(!$aqo){
echo "<script>alert('密码错误');history.go(-1);</script>";
}
else if(!$aq){
echo "<script>alert('账号不存在');history.go(-1);</script>";
}
else if(strpos($_GET["title"],"<")){
echo "<script>alert('标题中有危险内容');history.go(-1);</script>";
}
else if(strpos($_GET["title"],">")){
echo "<script>alert('标题中有危险内容');history.go(-1);</script>";
}
else if(strpos($_GET["contents"],"<")){
echo "<script>alert('内容中有危险内容');history.go(-1);</script>";
}
else if(strpos($_GET["contents"],">")){
echo "<script>alert('内容中有危险内容');history.go(-1);</script>";
}
else{
$query=mysqli_query($link,"select * from ".$_GET["user"]."text");
while($row=mysqli_fetch_array($query)){
if($id==$row["id"]){
$q=123;
}
}
if($q){
$title=str_ireplace("[br]","<br>",$_GET["title"]);
$contents=str_ireplace("[br]","<br>",$_GET["contents"]);
$xg=mysqli_query($link,"update ".$_GET["user"]."text set id='".$id."',title='".$title."',contents='".$contents."' where id=".$id);
if($xg){
echo "<script>alert('修改成功');history.go(-1);</script>";
}
else{
echo "<script>alert('命令执行时出现错误');history.go(-1);</script>";
}
}
else{
echo "<script>alert('参数错误');history.go(-1);</script>";
}
}
?>