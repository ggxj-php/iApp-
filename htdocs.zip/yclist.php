<?php
session_start();
?>
<meta charset="UTF-8" name="viewport" content="target-densitydpi=device-dpi,width=device-width, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0, user-scalable=no">
<title>iApp云后台-远程列表</title>
<center><button style="width:100%;height:50px;background:blue;color:white;" onclick="window.location.href='./tjlist.php';">添加远程列表</button>
<?php
include_once("./configure/link1.php");
inspect($_SESSION["login"]);
if($_SESSION["login"]){
if(mysqli_num_rows(mysqli_query($link,"show tables like '".$_SESSION["login"]."list'"))==0){
echo "<script>alert('发现您没有远程列表系统的数据表，如果要创建，请点击确定');</script>";
$create=mysqli_query($link,"CREATE TABLE ".$_SESSION["login"]."list (title text,id text)");
if($create){
echo "<script>alert('创建成功');window.location.href='./yclist.php';</script>";
}
else{
echo "<script>alert('创建失败，请重试');</script>";
}
}
else{
$query=mysqli_query($link,"select * from ".$_SESSION["login"]."list");
if(mysqli_num_rows($query)==0){
echo "您的数据库中没有任何列表</center>";
}
else{
$id=mysqli_num_rows($query);
while($id!==0){
$my=mysqli_query($link,"select * from ".$_SESSION["login"]."list where id=".$id);
while($row=mysqli_fetch_array($my)){
echo "<a href='./listcon.php?user=".$_SESSION["login"]."&id=".$row["id"]."'>".$row["title"]."</a><div style='width:100%;height:1px;background:black;'></div>";
if($id!==0){
$id=$id-1;
}
}
}
}
}
}
else{
echo "<script>alert('您还没有登录哦');window.location.href='./';</script>";
}
?>