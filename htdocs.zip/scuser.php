<meta charset="UTF-8" name="viewport" content="target-densitydpi=device-dpi,width=device-width, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0, user-scalable=no">
<?php
session_start();
error_reporting(E_ALL^E_NOTICE^E_WARNING);
if(!$_SESSION["login"]){
echo "<script>alert('您还没有登录哦');window.location.href='./';</script>";
}
else{
include_once("./configure/link1.php");
$query=mysqli_query($link,"select * from ".$_SESSION["login"]."user");
while($row=mysqli_fetch_array($query)){
if($row["user"]==$_GET["user"]){
$se="Matching success";
}
}
if($se){
$delete=mysqli_query($link,"delete from ".$_SESSION["login"]."user where user='".$_GET["user"]."'");
if($delete){
echo "删除成功";
}
else{
echo "删除失败";
}
}
}
?>