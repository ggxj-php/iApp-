<?php
session_start();
include_once("./configure/link1.php");
if(!$_SESSION["login"]){
echo "<script>alert('您还没有登录哦');history.go(-1);</script>";
}
else{
$query=mysqli_query($link,"select * from ".$_SESSION["login"]."text");
while($row=mysqli_fetch_array($query)){
if($row["id"]==$_GET["id"]){
$if=123;
}
}
if($if){
$quer=mysqli_query($link,"delete from ".$_SESSION["login"]."text where id='".$_GET["id"]."'");
if($quer){
echo "<script>alert('删除成功');history.go(-1);</script>";
}
else{
echo "<script>alert('命令执行错误');history.go(-1);</script>";
}
}
else{
echo "<script>alert('参数错误');history.go(-1);</script>";
}
}
?>