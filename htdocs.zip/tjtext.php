<?php
session_start();
if($_SESSION["login"]){
$title=$_POST["title"];
$contents=$_POST["contents"];
$q=$title;
$qq=$contents;
include_once("./configure/link1.php");
if($title==""){
echo "<script>alert('标题不能为空');history.go(-1);</script>";
}
else if($contents==""){
echo "<script>alert('内容不能为空');history.go(-1);</script>";
}
else if(strpos($q,"<")){
echo "<script>alert('标题中含有危险字符');history.go(-1);</script>";
}
else if(strpos($qq,"<")){
echo "<script>alert('内容中含有危险字符');history.go(-1);</script>";
}
else if(strpos($q,">")){
echo "<script>alert('标题中含有危险字符');history.go(-1);</script>";
}
else if(strpos($qq,">")){
echo "<script>alert('内容中含有危险字符');history.go(-1);</script>";
}
else{
$contents=str_ireplace("[br]","<br>",$contents);
$id=rand(1000,1000000);
$sql="insert into ".$_SESSION["login"]."text (id,title,contents) values('".$id."','".$title."','".$contents."')";
$query=mysqli_query($link,$sql);
if($query){
echo "<script>alert('上传成功');history.go(-1);</script>";
}
else{
echo "<script>alert('上传失败');history.go(-1);</script>";
}
}
}
else{
echo "<script>window.location.href='./';</script>";
}
?>