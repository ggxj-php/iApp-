<?php
include_once("./configure/link1.php");
$query=mysqli_query($link,"select * from login");
while($q=mysqli_fetch_array($query)){
if($q["user"]==$_GET["user"]){
$a="123";
}
}
if($a){

$quer=mysqli_query($link,"select * from ".$_GET["user"]."list");
while($row=mysqli_fetch_array($quer)){
if($row["id"]==$_GET["listid"]){
$aq="1";
}
}
if($aq){

$que=mysqli_query($link,"select * from ".$_GET["user"]."list".$_GET["listid"]);
while($rew=mysqli_fetch_array($que)){
if($rew["id"]==$_GET["id"]){
$qx="8";
}
}
if($qx){
//检测通过

$mysqli=mysqli_query($link,"delete from ".$_GET["user"]."list".$_GET["listid"]." where id=".$_GET["id"]);
if($mysqli){
echo "<script>alert('成功 注意:删除后列表顺序可能会发生错乱');history.go(-1);</script>";
}
else{
echo "<script>alert('失败');history.go(-1);</script>";
}

//检测通过
}
else{
echo "<script>alert('参数错误');</script>";
}

}
else{
echo "<script>alert('参数错误');</script>";
}

}
else{
echo "<script>alert('参数错误');</script>";
}
?>