<?php
session_start();
$user=$_GET["user"];
$xgpass=$_GET["xgpass"];
$xgjb=$_GET["xgjb"];
$xgfh=$_GET["xgfh"];
if($user==""||$xgpass==""||$xgjb==""){
echo "<script>alert('缺少必要参数');</script>";
}
else{
include_once("./configure/link1.php");
if(strpos($user," ")==true||strpos($xgpass," ")==true||strpos($xgjb," ")==true||strpos($xgfh," ")==true||strpos($user,"<")==true||strpos($xgpass,"<")==true||strpos($xgjb,"<")==true||strpos($xgfh,"<")==true||strpos($user,">")==true||strpos($xgpass,">")==true||strpos($xgjb,">")==true||strpos($xgfh,">")==true){
echo "<script>alert('请勿输入危险参数');</script>";
}
else{
$a=mysqli_query($link,"select * from login");
while($rw=mysqli_fetch_array($a)){
if($rw["user"]==$_GET["youruser"]){
$aq=1;
}
}
$b=mysqli_query($link,"select * from login");
while($rqw=mysqli_fetch_array($b)){
if($rqw["password"]==$_GET["yourpassword"]){
$aqo=1;
}
}
if(!$aq||!$aqo){
echo "您的账号或密码错误";
}
else{
$query=mysqli_query($link,"select * from ".$_GET["youruser"]."user");
while($row=mysqli_fetch_array($query)){
if($user==$row["user"]){
$q=1;
}
}
if($q){
if($xgfh==""){
$update=mysqli_query($link,"update ".$_GET["youruser"]."user set user='".$user."',password='".$xgpass."',goldcoin='".$xgjb."',fhint='',fh='',zt='正常' where user='".$user."'");
echo "<script>alert('修改成功');</script>";
}
else{
$f=str_replace("年","",$xgfh);
$fq=str_replace("月","",$f);
$fh=str_replace("日","",$fq);
$update=mysqli_query($link,"update ".$_GET["youruser"]."user set user='".$user."',password='".$xgpass."',goldcoin='".$xgjb."',fhint='".$fh."',fh='".$xgfh."',zt='禁封' where user='".$user."'");
echo "<script>alert('修改成功');</script>";
}
}
else{
echo "<script>alert('参数错误');</script>";
}
}
}
}
?>