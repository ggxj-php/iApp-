<meta charset="UTF-8" name="viewport" content="target-densitydpi=device-dpi,width=device-width, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0, user-scalable=no">
<?php
session_start();
include_once("./configure/link1.php");
$a=mysqli_query($link,"select * from login");
while($rw=mysqli_fetch_array($a)){
if($rw["user"]==$_GET["login"]){
$aq=1;
}
}
if(!$aq){
echo "参数错误";
}
else{
$query=mysqli_query($link,"select * from ".$_GET["login"]."user");
while($row=mysqli_fetch_array($query)){
if($row["user"]==$_GET["user"]){
$se="Matching success";
$nr="账号:".$row["user"]."<br>密码:".$row["password"]."<br>金币:".$row["goldcoin"]."<br>状态:".$row["zt"];
}
}
if($se){
echo $nr;
}
else{
echo "参数错误";
}
}
?>