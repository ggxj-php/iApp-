<?php
session_start();
include_once("./configure/link1.php");
?>
<meta charset="UTF-8" name="viewport" content="target-densitydpi=device-dpi,width=device-width, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0, user-scalable=no">
<head>
<title>iApp云后台</title>
</head>
<?php
$qu=mysqli_query($link,"select * from ".$_SESSION["login"]."km");
while($row=mysqli_fetch_array($qu)){
if($row["id"]==$_GET["id"]){
$if="yes";
}
}
if($if){
button("创建月卡卡密","./cjkm.php?type=month&id=".$_GET["id"]."&user=".$_SESSION["login"]);
button("创建天卡卡密","./cjkm.php?type=day&id=".$_GET["id"]."&user=".$_SESSION["login"]);
button("创建年卡卡密","./cjkm.php?type=year&id=".$_GET["id"]."&user=".$_SESSION["login"]);
echo "TIP:卡密使用接口-http://".$_SERVER["SERVER_NAME"]."/kmget.php?km=您要使用的卡密&user=".$_SESSION["login"]."&id=".$_GET["id"];
echo "<br>TIP:判断是否到期接口-http://".$_SERVER["SERVER_NAME"]."/kmif.php?date=您要判断的时间码";
echo "<center><h1>卡密列表</h1></center>";
$query=mysqli_query($link,"select * from ".$_SESSION["login"]."km".$_GET["id"]);
while($r=mysqli_fetch_array($query)){
line();
echo "<center>".$r["km"]."<br>到期时间:".$r["time"]."</center>";
line();
}
if(mysqli_num_rows($query)==0){
echo "<br><br><center>您的数据库是空的</center>";
}
}
else{
warn("参数错误");
}
?>