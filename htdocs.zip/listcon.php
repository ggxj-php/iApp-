<?php
session_start();
?>
<title>iApp云后台-远程列表</title>
<meta charset="UTF-8" name="viewport" content="target-densitydpi=device-dpi,width=device-width, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0, user-scalable=no">
<?php
include_once("./configure/link1.php");
$query=mysqli_query($link,"select * from login");
while($row=mysqli_fetch_array($query)){
if($row["user"]==$_GET["user"]){
$true=123;
}
}
if($true){
$qu=mysqli_query($link,"select * from ".$_GET["user"]."list");
while($r=mysqli_fetch_array($qu)){
if($r["id"]==$_GET["id"]){
$tq=123;
}
}
if($tq){
//检测通过

$list=mysqli_query($link,"select * from ".$_GET["user"]."list".$_GET["id"]);
if(mysqli_num_rows($list)==0){
echo "<center>您的列表是空的<br>TIP:发出列表内容接口-http://".$_SERVER["SERVER_NAME"]."/fslist.php?user=你的账号&title=标题&contens=内容&id=".$_GET["id"]."</center>";
}
else{
echo "<center>";
$q=mysqli_num_rows($list);
while($q!==0){
$cx=mysqli_query($link,"select * from ".$_GET["user"]."list".$_GET["id"]." where id=".$q);
while($arr=mysqli_fetch_array($cx)){
echo "<a href='./listnr.php?id=".$arr["id"]."&listid=".$_GET["id"]."&user=".$_GET["user"]."'>".$arr["title"]."</a>&nbsp;<a href='./sclist.php?id=".$arr["id"]."&user=".$_GET["user"]."&listid=".$_GET["id"]."'>删除</a><div style='background:black;width:100%;height:1px;'></div>";
}
if($q!==0){
$q=$q-1;
}
}
echo "TIP:发出列表内容接口-http://".$_SERVER["SERVER_NAME"]."/fslist.php?user=你的账号&title=标题&contens=内容&id=".$_GET["id"]."</center>";
}

//检测通过
}
else{
echo "<script>alert('参数错误');</script>";
}
}
else{
echo "<script>alert('参数错误');</script>";
}
?>