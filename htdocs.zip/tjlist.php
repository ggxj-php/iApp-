<?php
session_start();
error_reporting(E_ALL^E_NOTICE^E_WARNING);
?>
<!DOCTYPE html>
<html>
<meta charset="UTF-8" name="viewport" content="target-densitydpi=device-dpi,width=device-width, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0, user-scalable=no">
<head>
<title>iApp云后台-添加远程列表</title>
</head>
<body>
<form method="post" action="">
<input type="txt" name="listname" style="width:100%;height:35px;" placeholder="列表名称">
<input type="hidden" name="if" value="yes">
<button style="width:100%;height:50px;">添加</button>
</form>
</body>
</html>
<?php
if($_POST["if"]){
if(!$_SESSION["login"]){
echo "<script>alert('您还没有登录哦');window.location.href='./';</script>";
}
else{
include_once("./configure/link1.php");
if($_POST["listname"]==""){
echo "<script>alert('您还没有填写列表名称哦');</script>";
}
else if(strpos($_POST["listname"],"<")||strpos($_POST["listname"],">")||strpos($_POST["listname"],"'")){
echo "<script>alert('发现危险字符');</script>";
}
else{
$query=mysqli_query($link,"select * from ".$_SESSION["login"]."list");
while($row=mysqli_fetch_array($query)){
if($row["title"]==$_POST["listname"]){
$ro="1";
}
}
if($ro){
echo "<script>alert('名称不能重复');</script>";
}
else{
$rand=mysqli_num_rows($query)+1;
$q=mysqli_query($link,"CREATE TABLE ".$_SESSION["login"]."list".$rand." (title text,contents text,id text)");
$w=mysqli_query($link,"insert into ".$_SESSION["login"]."list (title,id) values('".$_POST["listname"]."','".$rand."')");
if($q&&$w){
echo "<script>alert('创建成功');</script>";
}
else{
echo "<script>alert('创建失败');</script>";
}
}
}
}
}
?>