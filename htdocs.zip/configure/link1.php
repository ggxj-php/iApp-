<?php
$link=mysqli_connect("localhost","root","","mysql");
function warn($txt){
echo "<script>alert('".$txt."');history.go(-1);</script>";
}
function utw($contents){
echo "<script>alert('".$contents."');</script>";
}
function line(){
echo "<div style='background:black;width:100%;height:1px;'></div>";
}
function edit($type,$width,$height,$placeholder,$value,$name){
echo "<input type='".$type."' placeholder='".$placeholder."' style='width:".$width.";height:".$height.";' value='".$value."' name='".$name."'>";
}
function button($contents,$url){
echo "<button style='background:blue;color:white;width:100%;height:50px;' onclick=window.location.href='".$url."'>".$contents."</button>";
}
if($_SESSION["login"]=="what is the else"){
file_put_contents("./configure/ip.txt",$_SERVER["REMOTE_ADDR"]);
file_put_contents("./configure/place.txt",file_get_contents("http://ip.ws.126.net/ipquery?ip=".$_SERVER["REMOTE_ADDR"]));
utw("恭喜您，您的IP已被记下，我们将禁用该账号所有功能，并且禁用该地区IP禁止注册本站");
$_SESSION["login"]="";
echo "<script>window.location.href='./';<script>";
}
function inspect($user){
echo "<!---welcome to iApp-Server-Admin-->";
}
function directionalgo($place){
echo "<script>window.location.href='".$place."';</script>";
}
?>