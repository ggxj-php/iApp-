<?php
session_start();
$id=$_GET["id"];
include_once("./configure/link1.php");
$cx=mysqli_query($link,"select * from login");
while($qw=mysqli_fetch_array($cx)){
if($qw["user"]==$_GET["user"]){
$aq=1;
$user=$qw["user"];
}
}
if($aq){
$query=mysqli_query($link,"select * from ".$_GET["user"]."text");
while($row=mysqli_fetch_array($query)){
if($id==$row["id"]){
$q="om";
$nr=$row["contents"];
}
}
if($q){
echo $nr;
}
else{
echo "<meta charset='UTF-8'><script>alert('Parameter error');history.go(-1);</script>";
}
}
else{
echo "<meta charset='UTF-8'><script>alert('Parameter error');history.go(-1);</script>";
}
?>