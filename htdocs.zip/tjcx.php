<?php
include_once("./configure/link1.php");
if(strpos($_GET["apk"],"<")){
echo "<script>alert('请勿输入危险字符');history.go(-1);</script>";
}
else if(strpos($_GET["apk"],">")){
echo "<script>alert('请勿输入危险字符');history.go(-1);</script>";
}
else if($_GET["apk"]==""){
echo "<script>alert('参数不能为空');history.go(-1);</script>";
}
else if(strpos($_GET["user"],"<")){
echo "<script>alert('请勿输入危险字符');history.go(-1);</script>";
}
else if(strpos($_GET["user"],">")){
echo "<script>alert('请勿输入危险字符');history.go(-1);</script>";
}
else if($_GET["user"]==""){
echo "<script>alert('参数不能为空');history.go(-1);</script>";
}
else{
$query=mysqli_query($link,"select * from ".$_GET["user"]."tj where apk='".$_GET["apk"]."'");
while($row=mysqli_fetch_array($query)){
$lj=$row["page"];
}
$date=date('Y-m-d H:i:s');
$content="[".$date."]IP:".$_SERVER['REMOTE_ADDR'];
$get=file_get_contents($lj.date("Y-m-d").".txt");
if($get==""){
$nr=$content;
}
else{
$nr=$get."\n".$content;
}
file_put_contents($lj.date("Y-m-d").".txt",$nr);
$get=file_get_contents($lj."pv.txt");
$contents=$get+1;
file_put_contents($lj."pv.txt",$contents);
$sr=str_replace(".","",file_get_contents($lj.date("Y-m-d")."独立IP.txt"));
$sr1=str_replace(".","",$_SERVER["REMOTE_ADDR"]);
foreach(explode("\n",$sr) as $cq){
if($sr1==$cq){
$pd="yes";
}
}
if($pd!=="yes"){
if(file_get_contents($lj.date("Y-m-d")."独立IP.txt")==""){
file_put_contents($lj.date("Y-m-d")."独立IP.txt",$_SERVER["REMOTE_ADDR"]);
}
else{
file_put_contents($lj.date("Y-m-d")."独立IP.txt",file_get_contents($lj.date("Y-m-d")."独立IP.txt")."\n".$_SERVER["REMOTE_ADDR"]);
}
}
$number=0;
foreach(explode("\n",file_get_contents($lj.date("Y-m-d")."独立IP.txt")) as $array){
$number=$number+1;
}
$number1=0;
foreach(explode("\n",file_get_contents($lj.date("Y-m-d").".txt")) as $array1){
$number1=$number1+1;
}
echo "<p style='color:blue;'>软件总pv[".file_get_contents($lj."pv.txt")."]今日pv[".$number1."]今日IP[".$number."]</p></div></body>";
}
?>