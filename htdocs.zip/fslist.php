<?php
session_start();
include_once("./configure/link1.php");
$qu=mysqli_query($link,"select * from login");
while($row=mysqli_fetch_array($qu)){
if($_GET["user"]==$row["user"]){
$if=123;
}
}
$quee=mysqli_query($link,"select * from ".$_SESSION["login"]."list");
while($q=mysqli_fetch_array($quee)){
if($_GET["id"]==$row["id"]){
$ift=999;
}
}
if($if){
if(strpos($_GET["id"],"'")||strpos($_GET["title"],">")||strpos($_GET["contents"],">")||strpos($_GET["title"],"<")||strpos($_GET["contents"],"<")){
echo "<script>alert('您的参数中有危险字符');</script>";
}
else{
//检测通过

$i=mysqli_query($link,"select * from ".$_GET["user"]."list".$_GET["id"]);
$q=mysqli_num_rows($i)+1;
$oq=mysqli_query($link,"insert into ".$_GET["user"]."list".$_GET["id"]." (title,contents,id) values('".$_GET["title"]."','".$_GET["contents"]."','".$q."')");
if($oq){
echo "<script>alert('成功');</script>";
}
else{
echo "<script>alert('失败');</script>";
}

//检测通过
}
}
else{
echo "<script>alert('参数错误');</script>";
}
?>