<?php
session_start();
?>
<meta charset="UTF-8" name="viewport" content="target-densitydpi=device-dpi,width=device-width, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0, user-scalable=no">
<title>iApp云后台-用户系统修改</title>
<form action="xgu.php" method="get">
<center>
<?php
if(strpos($_GET["user"],"<")||strpos($_GET["user"],">")){
echo "<script>alert('参数危险');history.go(-1);</script>";
exit;
}
else{
echo "<input type='hidden' value='".$_GET["user"]."' name='user'>";
}
?>
<input type="txt" style="width:100%;height:35px;" placeholder="请输入此人新的密码" name="xgpass">
<input type="txt" style="width:100%;height:35px;" placeholder="请输入此人金币数" name="xgjb">
<?php
echo "<input type='hidden' value='".$_SESSION["login"]."' name='youruser'>";
?>
<input type="txt" style="width:100%;height:35px;" placeholder="请输入您的密码" name="yourpassword">
禁封截止时间(可空 空则是不禁封,需要写年月日，并且要8位,例:2000年01月01日:
<input type="txt" style="width:100%;height:45px;" name="xgfh">
<button style="width:100%;height:50px">提交</button>
</center>
</form>
<?php
echo "TIP:修改接口-http://".$_SERVER["SERVER_NAME"]."/xgu.php?user=要修改的人的账号&xgpass=要修改的密码&xgjb=要修改的金币数&youruser=您在本站的账号&yourpassword=您在本站的密码&xgfh=同上提示(可空)";
?>