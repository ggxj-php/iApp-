<?php
include_once("./configure/link1.php");
$query=mysqli_query($link,"select * from login");
while($q=mysqli_fetch_array($query)){
if($q["user"]==$_GET["user"]){
$a="123";
}
}
if($a){

$quer=mysqli_query($link,"select * from ".$_GET["user"]."list");
while($row=mysqli_fetch_array($quer)){
if($row["id"]==$_GET["listid"]){
$aq="1";
}
}
if($aq){

$que=mysqli_query($link,"select * from ".$_GET["user"]."list".$_GET["listid"]);
while($rew=mysqli_fetch_array($que)){
if($rew["id"]==$_GET["id"]){
$qx="8";
}
}
if($qx){
//检测通过

$mysqli=mysqli_query($link,"select * from ".$_GET["user"]."list".$_GET["listid"]." where id=".$_GET["id"]);
while($v=mysqli_fetch_array($mysqli)){
echo "<title>".$v["title"]."</title>".$v["contents"];
}

//检测通过
}
else{
echo "<script>alert('参数错误');</script>";
}

}
else{
echo "<script>alert('参数错误');</script>";
}

}
else{
echo "<script>alert('参数错误');</script>";
}
?>