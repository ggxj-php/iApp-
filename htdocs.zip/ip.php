<meta charset="UTF-8" name="viewport" content="target-densitydpi=device-dpi,width=device-width, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0, user-scalable=no">
<center>
<title>iApp云后台-IP获取</title>
<?php
echo "您的IP:".$_SERVER["REMOTE_ADDR"];
?>
</center>
<?php
echo "TIP:IP获取接口-http://".$_SERVER["SERVER_NAME"]."/ipgetapi.php";
?>