<?php
if($_GET["date"]==""){
echo "缺少必要参数";
}
else if($_GET["date"]>=date("YmdHis")){
echo "未到期";
}
else{
echo "已到期";
}
?>