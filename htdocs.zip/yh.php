<?php
session_start();
?>
<meta charset="UTF-8" name="viewport" content="target-densitydpi=device-dpi,width=device-width, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0, user-scalable=no">
<title>iApp云后台-用户系统</title>
<?php
include_once("./configure/link1.php");
inspect($_SESSION["login"]);
$query=mysqli_query($link,"select * from ".$_SESSION["login"]."user");
while($row=mysqli_fetch_array($query)){
echo $row["user"]."&nbsp;<a href='./ckuser.php?user=".$row["user"]."&login=".$_SESSION["login"]."'>查看</a>&nbsp;<a href='./scuser.php?user=".$row["user"]."'>删除</a>&nbsp;<a href='./xguser.php?user=".$row['user']."'>修改</a><div style='background:black;width:100%;height:1px;'>";
}
if(mysqli_num_rows($query)==0){
echo "您的数据库中没有用户";
}
echo "<p style='color:red'>TIP:注册接口-http://".$_SERVER["SERVER_NAME"]."/zcjk.php?user=注册的账号&password=密码&youruser=在本后台中你的账号<br>登录接口:http://".$_SERVER["SERVER_NAME"]."/dljk.php?user=账号&password=密码&youruser=在本后台中你的账号</p>";
if(!$_SESSION["login"]){
echo "<script>alert('您还没有登录哦');window.location.href='./';</script>";
}
?>