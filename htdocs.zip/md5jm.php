<?php
session_start();
include_once("./configure/link1.php");
if(!$_SESSION["login"]){
echo "<script>alert('您还没有登录哦');window.location.href='./';</script>";
}
inspect($_SESSION["login"]);
?>
<meta charset="UTF-8" name="viewport" content="target-densitydpi=device-dpi,width=device-width, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0, user-scalable=no">
<title>iApp云后台-MD5解密</title>
<form method="get" action="md5jmget.php">
<input type="txt" placeholder="请输入需要解密的MD5" style="width:100%;height:50px;" name="md5">
<button style='width:100%;height:50px;background:blue;color:white;'>解密</button>
</form>
<?php
echo "TIP:MD5解密接口-http://".$_SERVER["SERVER_NAME"]."/md5jmget.php?md5=需要解密的字符";
?>