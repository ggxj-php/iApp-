<?php
session_start();
Header("Content-type: image/gif");
$im = imagecreate(100,40);
$black = ImageColorAllocate($im, rand(1,100),rand(200,999),rand(10,9999));
$white = ImageColorAllocate($im, 255,255,255);
imageline($im, 1, 1, 350, 25, $black);
imagearc($im, 200, 15, 20, 20, 35, 190, $white);
$rand=rand(1000,9999);
$_SESSION["yzm"]=$rand;
imagestring($im, 5, 4, 10, $rand,$white);
 $linecolor = imagecolorallocate($im,rand(80,220), rand(80,220),rand(80,220));
imageline($im,rand(1,99), rand(1,29),rand(1,99), rand(1,29),$linecolor);
 for($i=0;$i<200;$i++){
    //设置点的颜色，50-200颜色比数字浅，不干扰阅读
    $pointcolor = imagecolorallocate($im,rand(50,200), rand(50,200), rand(50,200));    
    //imagesetpixel — 画一个单一像素
    imagesetpixel($im, rand(1,99), rand(1,29), $pointcolor);
  }
ImageGif($im);
ImageDestroy($im);
?>