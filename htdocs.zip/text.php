<meta charset="UTF-8" name="viewport" content="target-densitydpi=device-dpi,width=device-width, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0, user-scalable=no">
<button style="width:100%;height:50px;background:blue;color:white" onclick="window.location.href='./tjtext.html';">创建新远程文本</button>
<title>iApp云后台-远程文本</title>
<script>
alert("提示:如果您要输入空格，请用‘’&nbsp;‘’代替，一个‘’&nbsp;’’代表一个空格，如果要换行请用‘‘[br]’’代替，一个‘‘[br]’’代表一次换行");
</script>
<body>
<?php
session_start();
error_reporting(E_ALL^E_NOTICE^E_WARNING);
include_once("./configure/link1.php");
inspect($_SESSION["login"]);
$query=mysqli_query($link,"select * from ".$_SESSION["login"]."text");
while($row=mysqli_fetch_array($query)){
echo "<center><a href='./textcon.php?id=".$row["id"]."&user=".$_SESSION["login"]."'>".$row["title"]."</a>&nbsp;[控制区]<a href='./textxg.php?id=".$row["id"]."'>修改</a>&nbsp;<a href='./delect.php?id=".$row["id"]."'>删除</a></center><div style='width:100%;height:1px;background:black;'></div>";
}
$num=mysqli_num_rows($query);
if($num==0){
echo "<center><p>您的数据库中没有远程文本哦</p></center>";
}
if(!$_SESSION["login"]){
echo "<script>window.location.href='./';</script>";
}
?>
</body>